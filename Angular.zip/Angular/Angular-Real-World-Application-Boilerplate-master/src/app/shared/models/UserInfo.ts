export interface UserInfo {
    username: string,
    password: string,
    userType: string
}