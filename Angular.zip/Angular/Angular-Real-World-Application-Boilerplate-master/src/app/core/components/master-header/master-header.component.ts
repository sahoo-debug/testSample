import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'master-header',
  templateUrl: './master-header.component.html',
  styleUrls: ['./master-header.component.scss']
})
export class MasterHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
