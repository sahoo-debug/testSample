import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-footer',
  templateUrl: './master-footer.component.html',
  styleUrls: ['./master-footer.component.scss']
})
export class MasterFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
