﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCode
{
    public class EmployeeService
    {
        public string GetName(Employee emp)
        {
            if (string.IsNullOrEmpty(emp.FirstName)) throw new ArgumentNullException("first is empty");
            return string.Concat(emp.FirstName, " ", emp.LastName);
        }

        
    }
}
