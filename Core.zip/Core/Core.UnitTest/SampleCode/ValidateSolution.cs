﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCode
{
   public class ValidateSolution
    {
        public IValidate _validate;
        public ValidateSolution(IValidate validate )
        {
            _validate = validate;
        }
        public int ValidateWithAdd(int first, int second)
        {
            var isValid = _validate.ValidateIntupt();
            if (isValid)
            {
                return first + second;
            }
            return first;
        }

    }
}
