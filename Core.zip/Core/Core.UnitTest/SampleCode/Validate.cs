﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCode
{
   public class Validate : IValidate
    {
        public bool ValidateIntupt()
        {
            return false;
        }
    }

    public interface IValidate
    {
        bool ValidateIntupt();
    }
}
