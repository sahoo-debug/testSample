using Moq;
using NUnit.Framework;
using SampleCode;
using System;

namespace UnitTest.Nunit
{
    [TestFixture]
    public class EmpTest
    {
        public EmpTest()
        {

        }

        [TestCase("abc", "xyz", "abc xyz")]
        [TestCase("", "xyz", "first is empty")]
        [Test]
        public void Validate_Employename_Test(string firstname, string lastname, string actualvalue)
        {
            var emp = new Employee { FirstName= firstname, LastName = lastname };

            if (string.IsNullOrEmpty(firstname))
            {
                var ex = Assert.Throws<ArgumentNullException>(() => new EmployeeService().GetName(emp));
                Assert.That(ex.ParamName, Is.EqualTo(actualvalue));
            }
            else
            {
                var empname = new EmployeeService().GetName(emp);
                Assert.AreEqual(empname, actualvalue);
            }           
        }

        [TestCase(5, 3, true, 8)]
        [TestCase(8,6, false, 8) ]
        [Test]
        public void ValidateWithAdd_Test_For_Return_addition(int a, int b, bool valid, int sum)
        {
            var mock = new Mock<IValidate>();
            mock.Setup(x => x.ValidateIntupt()).Returns(valid);
            var validateobj = new ValidateSolution(mock.Object);
            var result = validateobj.ValidateWithAdd(a,b);
            Assert.AreEqual(sum, result);
        }

        [Ignore("not require")]
        [Test]
        public void Valiadate_Employeedata()
        {

        }
    }
}