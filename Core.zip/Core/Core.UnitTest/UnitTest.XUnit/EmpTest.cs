using Moq;
using SampleCode;
using System;
using Xunit;

namespace UnitTest.XUnit
{
    public class EmpTest
    {
        [Fact]
        public void Validate_Employename_Test()
        {
            //var emp = new Employee { FirstName = firstname, LastName = lastname };

            //if (string.IsNullOrEmpty(firstname))
            //{
            //    var ex = Assert.Throws<ArgumentNullException>(() => new EmployeeService().GetName(emp));
            //    Assert.That(ex.ParamName, Is.EqualTo(actualvalue));
            //}
            //else
            //{
            //    var empname = new EmployeeService().GetName(emp);
            //    Assert.AreEqual(empname, actualvalue);
            //}
        }

        [Theory]
        [InlineData(5, 3, true, 8)]
        [InlineData(8, 6, false, 8)]
        //[Fact] not require
        public void ValidateWithAdd_Test_For_Return_addition(int a, int b, bool valid, int sum)
        {
            var mock = new Mock<IValidate>();
            mock.Setup(x => x.ValidateIntupt()).Returns(valid);
            var validateobj = new ValidateSolution(mock.Object);
            var result = validateobj.ValidateWithAdd(a, b);
            Assert.Equal(sum, result);
        }


        [Fact]
        public void Valiadate_Employeedata()
        {

        }
    }
}
