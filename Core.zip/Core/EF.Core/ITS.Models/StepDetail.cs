﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITS.Models
{
   public class StepDetail
    {
        public string StepName { get; set; }
        public string FullName { get; set; }
    }
}
