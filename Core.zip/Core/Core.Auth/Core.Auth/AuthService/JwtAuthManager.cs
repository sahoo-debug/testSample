﻿using Core.Auth.Helpers;
using Core.Auth.Models;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Core.Auth.AuthService
{
    public class JwtAuthManager: IJwtAuthManager
    {
        private readonly AppSettings _appSettings;
        public JwtAuthManager(IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
        }
        public UserModel Authenticate(AuthModel user, string secretKey= null)
        {
            UserModel userEntity = null;
            if (secretKey != null)
            {
                if(secretKey == _appSettings.Secret)
                {
                    userEntity = UserModel.UserList().Where(x => x.UserName == user.UserName && x.Password == user.Password).FirstOrDefault();
                    if (userEntity != null)
                    {
                        userEntity.Token = GenerateJwtToken(userEntity);
                        userEntity.Password = null;
                    }
                }
            }
            return userEntity;
        }

        private string GenerateJwtToken(UserModel user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[] { new Claim("UserId", user.UserId.ToString()) }),
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
