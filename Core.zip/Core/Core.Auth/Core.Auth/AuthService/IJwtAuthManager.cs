﻿using Core.Auth.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Auth.AuthService
{
   public interface IJwtAuthManager
    {
        UserModel Authenticate(AuthModel user, string secretKey=null);
    }
}
