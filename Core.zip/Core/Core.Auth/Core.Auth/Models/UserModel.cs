﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Core.Auth.Models
{
    public class AuthModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }

        

    }

    public class UserModel
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        [JsonIgnore]
        public string Password { get; set; }
        public string Token { get; set; }


        public static IList<UserModel> UserList()
        {
            var users = new List<UserModel>()
                {
                   new UserModel { UserName = "user1", Password ="password1" },
                   new UserModel { UserName = "user2", Password ="password2"},
                };

            return users;
        }
    }
}
