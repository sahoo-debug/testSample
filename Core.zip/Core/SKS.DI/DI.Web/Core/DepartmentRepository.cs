﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DI.Web.Core
{
    //public class DepartmentRepository : IDepartmentRepository
    //{
    //    public string GetDepartment()
    //    {
    //        return "Hello SKS Depaartment";
    //    }
    //}
}
