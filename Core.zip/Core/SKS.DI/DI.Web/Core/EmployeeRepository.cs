﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DI.Web.Core
{
    //public class EmployeeRepository : IEmployeeRepository
    //{
    //    public string Display()
    //    {
    //        return "Hello SKS";
    //    }
    //}
}
