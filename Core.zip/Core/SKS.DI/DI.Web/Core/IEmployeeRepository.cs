﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DI.Web.Core
{
   //public interface IEmployeeRepository
   // {
   //     string Display();
   // }
}
