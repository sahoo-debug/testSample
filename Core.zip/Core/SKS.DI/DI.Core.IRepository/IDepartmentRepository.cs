﻿namespace DI.Core.IRepository
{
    public interface IDepartmentRepository
    {
        string GetDepartment();
    }
}
