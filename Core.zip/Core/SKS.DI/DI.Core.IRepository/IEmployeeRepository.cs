﻿namespace DI.Core.IRepository
{
    public interface IEmployeeRepository
    {
        string Display();
    }
}
