﻿namespace DI.Services.Contract
{
    public interface IDepartmentService
    {
        string GetDepartment();
    }
}
