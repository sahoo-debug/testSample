﻿namespace DI.Services.Contract
{
    public interface IEmployeeService
    {
        string Display();
    }
}
