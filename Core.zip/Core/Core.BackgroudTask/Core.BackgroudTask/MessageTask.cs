﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Core.BackgroudTask
{
    public class MessageTask: BackgroundService
    {
        public readonly IWorker _worker;
        public MessageTask(IWorker worker)
        {
            _worker = worker;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
           await _worker.DoWork(stoppingToken);
        }
    }
}
