﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Core.BackgroudTask
{
    public class Worker: IWorker
    {
        public readonly ILogger<Worker> _logger;
        public int numbervalue = 0;
        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }
        public async Task DoWork(CancellationToken concelletion)
        {
            while(!concelletion.IsCancellationRequested)
            {
                GetCurrent(ref numbervalue);
                _logger.LogInformation($"Current Value: {numbervalue}");
                await Task.Delay(3000);
            }
        }

        public void GetCurrent(ref int numbervalue)
        {
            numbervalue = numbervalue + 1;
        }
    }
}
