﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleLogic
{
    public class Publisher
    {
        public string UserName { get; set; }

        // public delegate void VideoUploadHandler(object sender, EventArgs e);
        //public event VideoUploadHandler VideoUploadEvent;
        public event EventHandler VideoUploadEvent;

        public void Upload()
        {
            Console.WriteLine("Video uploaded in server");
            //
            OnvideoUploadEvent();
        }
        public virtual void OnvideoUploadEvent()
        {
            VideoUploadEvent?.Invoke(this, EventArgs.Empty);
        }
    }

    public class Subscriber
    {
        public void AcceptEvent(Publisher publisher)
        {
            publisher.VideoUploadEvent += VideoUploadEvent;
        }

        public void VideoUploadEvent(object sender, EventArgs e)
        {
            var _publisher = (Publisher)sender;
            Console.WriteLine("Video uploaded by admin: " + _publisher.UserName);
        }
    }

    public class EventClient
    {
        public static void Main5(string[] args)
        {
            var _publisher = new Publisher { UserName="SKS"};
            var _subscriber = new Subscriber();
            _subscriber.AcceptEvent(_publisher);
            _publisher.Upload(); 
        }
    }
}
