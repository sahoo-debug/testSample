﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleLogic
{
    class FactoryClient
    {
        //static void Main(string[] args)
        //{
        //    ICarFactory carfactory = new CarFactory();
        //    ICar car = carfactory.GetCar(2);
        //    Console.WriteLine(car.GetCarSpeed());
        //}
    }
    public interface ICar
    {
        string GetCarSpeed();
        string GetCarPrice();
    }

    public interface ICarFactory
    {
        ICar GetCar(int type);
    }
    public class CarFactory: ICarFactory
    {
        public ICar GetCar(int type)
        {
            ICar car = null;
            switch(type)
            {
                case 1:
                    car = new Baleno();
                    break;
                case 2:
                    car = new Ciaz();
                    break;
            }
            return car;
        }
    }

    public class Baleno:ICar
    {
        public string GetCarSpeed()
        {
            return "100";
        }
        public string GetCarPrice()
        {
            return "5000";
        }
    }

    public class Ciaz : ICar
    {
        public string GetCarSpeed()
        {
            return "200";
        }
        public string GetCarPrice()
        {
            return "8000";
        }
    }
}
