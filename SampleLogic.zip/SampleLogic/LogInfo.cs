﻿using NLog;
using System;

namespace SampleLogic
{
  public  class LogInfo
    {
        public static Logger logger = LogManager.GetCurrentClassLogger();

        public static void ErrorLog(string errorMessage)
        {
            logger.Error(errorMessage);
        }

        public static void InfoLog(string infoMessage)
        {
            logger.Info(infoMessage);
        }

        public static void DebugLog(string debugMessage)
        {
            logger.Debug(debugMessage);
        }
    }
}
