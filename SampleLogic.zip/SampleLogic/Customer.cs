﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleLogic
{
   public class Customer
    {
        private double balance;
        public double Balance
        {
            //get
            //{
            //    return balance;
            //}
            set
            {
                // validate the value
                if (value < 0)
                {
                    Console.WriteLine("value cannot be negative");
                }
                balance = value + 100;
            }
        }
    }
}


//using System;
//using System.Collections.Generic;

//namespace SampleLogic
//{
//    public class SampleTest
//    {
//        static void Main(string[] args)
//        {
//            int testCases = Convert.ToInt32(Console.ReadLine());



//            List<int[]> arrList = new List<int[]>();
//            for (int i = 1; i <= testCases; i++)
//            {
//                int arrSize = Convert.ToInt32(Console.ReadLine());
//                string numbers = Console.ReadLine();
//                var arrNumber = numbers.Split(' ');
//                int[] arr = Array.ConvertAll(arrNumber, x => Convert.ToInt32(x));
//                arrList.Add(arr);
//            }



//            foreach (var item in arrList)
//            {
//                int itemLength = item.Length;
//                int result = GetTripletValue(item, itemLength);
//                Console.WriteLine(result);
//            }
//        }

//        static int GetTripletValue(int[] arr, int length)
//        {
//            int result = 0;
//            for (int i = 1; i < length - 1; ++i)
//            {
//                int maximum1 = 0, maximum2 = 0;
//                for (int j = 0; j < i; ++j)
//                {
//                    if (arr[j] < arr[i])
//                    {
//                        maximum1 = Math.Max(maximum1, arr[j]);
//                    }
//                }
//                for (int j = i + 1; j < length; ++j)
//                {
//                    if (arr[j] > arr[i])
//                    {
//                        maximum2 = Math.Max(maximum2, arr[j]);
//                    }
//                }

//                int maximum = maximum1 + (arr[i] * maximum2);
//                result = Math.Max(result, maximum);
//            }
//            return result;
//        }
//    }
//}

