﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleLogic
{
    public class Person //: IEquatable<Person>
    {
        public string Name { get; set; }
        public int Age { get; set; }

        //public override bool Equals(object obj)
        //{
        //    return base.Equals(obj);
        //}

        public bool Equals(Person person)
        {
            Person p = new Person();
            var aa = p.GetHashCode();
            object ob = new object();
            var oo = ob.GetHashCode();
            return false;
        }
    }
}
