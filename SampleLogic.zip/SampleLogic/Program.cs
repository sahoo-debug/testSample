﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleLogic
{
    class Program
    {
        static void Main2(string[] args)
        {
            //Customer obj = new Customer();
            //obj.Balance = 100;
            //Console.WriteLine(obj.Balance);
            //obj.Balance = -50;
            //Console.WriteLine(obj.Balance);
            //Console.WriteLine("Press any key to exist.");
            //Console.ReadKey();

            //TestClassB objB = new TestClassB();
            //objB.DisplayA();
            //objB.DisplayAA();
            //objB.DisplayAAA();

            //TestClassA refA = new TestClassB();
            //refA.DisplayA();
            //refA.DisplayAA();
            //refA.DisplayAAA();

            //Console.WriteLine("Number Count.");
            //string numberCount =Console.ReadLine();
            //Console.WriteLine("Enter numbers");
            //string numbers = Console.ReadLine();

            //var arrNumber = numbers.Split(' ');
            //int[] arr = Array.ConvertAll(arrNumber, x=> int.Parse(x));
            //int min =Convert.ToInt32(arrNumber[0]);
            //if (Convert.ToInt32(numberCount) == arrNumber.Length)
            //{
            //    for(int i =1; i<arrNumber.Length; i++)
            //    {
            //        if(Convert.ToInt32(arrNumber[i]) < min)
            //        {
            //            min = Convert.ToInt32(arrNumber[i]);
            //        }
            //    }
            //    Console.WriteLine("Minimum value is {0}", min);
            //}

            string str = "acdc";
            int N = str.Length;
            int[,] cps = new int[N + 1, N + 1];

            for (int i = 0; i < N; i++)
                cps[i, i] = 1;

            for (int L = 2; L <= N; L++)
            {
                for (int i = 0; i < N; i++)
                {
                    int k = L + i - 1;
                    if (k < N)
                    {
                        if (str[i] == str[k])
                            cps[i, k] = cps[i, k - 1] +
                                        cps[i + 1, k] + 1;
                        else
                            cps[i, k] = cps[i, k - 1] +
                                        cps[i + 1, k] -
                                        cps[i + 1, k - 1];
                    }
                }
            }
            int result = cps[0, N - 1];
            Console.WriteLine("Result: " + result);
        }
    }
}
