﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleLogic
{
   public class TestClassA
    {
        public virtual void DisplayA()
        {
            Console.WriteLine("print: Parent DisplayA");
            LogInfo.InfoLog("Info :Parent DisplayA");
        }
        public void DisplayAA()
        {
            Console.WriteLine("print: Parent DisplayAA");
            LogInfo.InfoLog("Info :Parent DisplayAA");
        }
        public virtual void DisplayAAA()
        {
            Console.WriteLine("print:Parent DisplayAAA");
            LogInfo.InfoLog("Info :Parent DisplayAAA");
        }

        public string FindAddress(string name, string area = null)
        {
            return "second method :" + name;
        }
        public string FindAddress(string name)
        {
            return "first method :" + name;
        }
       
        public void Test()
        {
            
        }
    }

    public class ExecuteProgram
    {
        public static void Main(string[] args)
        {
            TestClassA obj = new TestClassA();
            var value = obj.FindAddress("name1");
            Console.WriteLine(value);
        }
    }
    //public class TestClassB: TestClassA
    //{
    //    public void DisplayA()
    //    {
    //        Console.WriteLine("print:child DisplayA");
    //        LogInfo.ErrorLog("Error :Parent DisplayA");
    //    }
    //    public new void DisplayAA()
    //    {
    //        Console.WriteLine("print:child DisplayAA");
    //        LogInfo.ErrorLog("Error :Parent DisplayAA");
    //    }
    //    public override void DisplayAAA()
    //    {
    //        Console.WriteLine("print:child DisplayAAA");
    //        LogInfo.ErrorLog("Error :Parent DisplayAAA");
    //    }
    //}
}
