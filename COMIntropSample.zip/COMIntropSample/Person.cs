﻿using System;
using System.Text;
using System.IO;
using System.Xml.Serialization;
namespace COMIntropSample
{
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool IsMale { get; set; }
        public void Persist(string FilePath)
        {
            StreamWriter oFile = new StreamWriter(FilePath);
            XmlSerializer oXmlSerializer = new XmlSerializer(typeof(Person));
            oXmlSerializer.Serialize(oFile, this);
            oFile.Flush();
            oFile.Close();
        }
    }
}
